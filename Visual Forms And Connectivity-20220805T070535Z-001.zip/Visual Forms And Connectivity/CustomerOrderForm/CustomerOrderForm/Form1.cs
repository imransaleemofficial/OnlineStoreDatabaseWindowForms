﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;

namespace CustomerOrderForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            string se = ConfigurationManager.ConnectionStrings["OnlineStore"].ConnectionString;
            SqlConnection con = new SqlConnection(se);
            string query = "insert into CustomerOrder values(@CustomerID,@Orders,@Cash On Delivery,@Online Payment,@Address,@City,@Payment)";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@CustomerID", CustomerID.Text);
            cmd.Parameters.AddWithValue("@Orders", CR.Text);
            cmd.Parameters.AddWithValue("@Cash On Delivery", IM.Text);
            cmd.Parameters.AddWithValue("@Online Payment", LM.Text);
            cmd.Parameters.AddWithValue("@Address", OS.Text);
            cmd.Parameters.AddWithValue("@City", R.Text);
            cmd.Parameters.AddWithValue("@Payment", S.Text);
            con.Open();
            int a = cmd.ExecuteNonQuery();
            if (a > 0)
            {
                MessageBox.Show("successfully executed");

            }
            else
            {
                MessageBox.Show("successfully not executed");
            }
            con.Close();
        }
    }

}
